def start_playing(obj):
    return obj.play()