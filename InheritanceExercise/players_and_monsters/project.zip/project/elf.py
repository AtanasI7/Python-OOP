from project.hero import Hero


class Elf(Hero):
    pass