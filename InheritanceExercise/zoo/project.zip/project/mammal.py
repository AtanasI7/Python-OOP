from project.animal import Animal


class Mammal(Animal):
    pass
    # def __init__(self, name):
    #     super().__init__(name)